<?php
require_once "config.php";

function generateReference(mysqli $conn): string {
    // HP000001 style based on AUTO_INCREMENT id
    $res = $conn->query("SELECT MAX(id) AS max_id FROM bookings");
    $row = $res ? $res->fetch_assoc() : null;

    $nextId = (!empty($row["max_id"])) ? ((int)$row["max_id"] + 1) : 1;
    return "HP" . str_pad((string)$nextId, 6, "0", STR_PAD_LEFT);
}

function requireAdminLogin(): void {
    if (empty($_SESSION["logged_in"])) {
        header("Location: login.php");
        exit();
    }
}
?>
