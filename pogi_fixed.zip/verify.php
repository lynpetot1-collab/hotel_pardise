<?php
require_once "config.php";

$reference = "";
$message = "";

if (isset($_POST["verify"])) {
    $reference = strtoupper(trim($_POST["reference"] ?? ""));

    if ($reference === "") {
        $message = "<div class='alert alert-error'>Please enter a reference number.</div>";
    } else {
        $stmt = $conn->prepare("SELECT * FROM bookings WHERE reference = ? LIMIT 1");
        $stmt->bind_param("s", $reference);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows === 1) {
            $b = $res->fetch_assoc();
            $message = "
              <div class='alert alert-success'>
                <strong>Booking Verified!</strong><br><br>
                <strong>Reference:</strong> ".htmlspecialchars($b["reference"])."<br>
                <strong>Name:</strong> ".htmlspecialchars($b["name"])."<br>
                <strong>Email:</strong> ".htmlspecialchars($b["email"])."<br>
                <strong>Phone:</strong> ".htmlspecialchars($b["phone"])."<br>
                <strong>Check-in:</strong> ".htmlspecialchars($b["checkin"])."<br>
                <strong>Check-out:</strong> ".htmlspecialchars($b["checkout"])."<br>
                <strong>Guests:</strong> ".htmlspecialchars($b["guests"])."<br>
                <strong>Room Type:</strong> ".htmlspecialchars($b["room_type"])."<br>
                <strong>Status:</strong> ".htmlspecialchars($b["status"])."<br>
              </div>
            ";
        } else {
            $message = "<div class='alert alert-error'>No booking found for that reference.</div>";
        }
        $stmt->close();
    }
}

include "header.php";
?>

<div class="page-title">
  <h1>Verify Booking</h1>
  <p>Enter your reference number to check your booking.</p>
</div>

<div class="form-container">
  <h2>Reference Number</h2>
  <form method="POST">
    <div class="form-group">
      <input type="text" name="reference" placeholder="e.g. HP000001" value="<?php echo htmlspecialchars($reference); ?>" required>
    </div>
    <button class="btn btn-block" type="submit" name="verify">Verify</button>
  </form>

  <div style="margin-top:20px;">
    <?php echo $message; ?>
  </div>
</div>

<?php include "footer.php"; ?>
