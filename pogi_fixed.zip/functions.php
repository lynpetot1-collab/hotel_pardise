<?php
// Backward-compatible include. Some pages require "functions.php" but the file is named "function.php".
require_once __DIR__ . "/function.php";
?>
