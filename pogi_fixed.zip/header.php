<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Paradise</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="header">
  <div class="container">
    <nav class="navbar">
      <div class="logo"><h1>Hotel Paradise</h1></div>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="verify.php">Verify Booking</a></li>
        <li><a href="admin.php">Admin</a></li>
        <?php if (!empty($_SESSION["logged_in"])): ?>
          <li><a href="logout.php" class="btn-login">Logout (<?php echo htmlspecialchars($_SESSION["username"]); ?>)</a></li>
        <?php else: ?>
          <li><a href="login.php" class="btn-login">Admin Login</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</header>

<main class="main-content">
  <div class="container">
