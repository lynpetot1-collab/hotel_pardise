<?php
$DB_HOST = "sql103.infinityfree.com";
$DB_USER = "if0_41024645";
$DB_PASS = "Ab580x6MqU";
$DB_NAME = "if0_41024645_clstialhtl";

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
