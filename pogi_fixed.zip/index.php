<?php
require_once "config.php";
include "header.php";
?>

<div class="page-title">
  <h1>Book Your Stay</h1>
  <p>Experience comfort and easy booking</p>
</div>

<?php if (!empty($_GET["success"]) && !empty($_GET["ref"])): ?>
  <div class="alert alert-success">
    Booking successful! Your reference number is:
    <strong><?php echo htmlspecialchars($_GET["ref"]); ?></strong>
  </div>
<?php endif; ?>

<div class="form-container">
  <h2>Booking Form</h2>

  <form action="book.php" method="POST">
    <div class="form-group">
      <label>Full Name</label>
      <input type="text" name="name" required>
    </div>

    <div class="form-group">
      <label>Email Address</label>
      <input type="email" name="email" required>
    </div>

    <div class="form-group">
      <label>Phone Number</label>
      <input type="text" name="phone" required>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Check-in Date</label>
        <input type="date" name="checkin" required>
      </div>
      <div class="form-group">
        <label>Check-out Date</label>
        <input type="date" name="checkout" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Guests</label>
        <select name="guests" required>
          <option value="">Select</option>
          <option value="1">1 Guest</option>
          <option value="2">2 Guests</option>
          <option value="3">3 Guests</option>
          <option value="4">4 Guests</option>
        </select>
      </div>

      <div class="form-group">
        <label>Room Type</label>
        <select name="room_type" required>
          <option value="">Select</option>
          <option value="standard">Standard Room</option>
          <option value="deluxe">Deluxe Room</option>
          <option value="suite">Suite</option>
        </select>
      </div>
    </div>

    <button class="btn btn-block" type="submit">Book Now</button>
  </form>
</div>

<?php include "footer.php"; ?>
