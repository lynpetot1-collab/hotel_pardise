<?php
require_once "functions.php";
requireAdminLogin();

$res = $conn->query("SELECT * FROM bookings ORDER BY id DESC");
include "header.php";
?>

<div class="page-title">
  <h1>Admin Panel</h1>
  <p>Manage bookings (confirm / cancel / delete)</p>
</div>

<div class="table-container">
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Reference</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Check-in</th>
        <th>Check-out</th>
        <th>Guests</th>
        <th>Room</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>

    <tbody>
      <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?php echo (int)$row["id"]; ?></td>
          <td><strong><?php echo htmlspecialchars($row["reference"]); ?></strong></td>
          <td><?php echo htmlspecialchars($row["name"]); ?></td>
          <td><?php echo htmlspecialchars($row["email"]); ?></td>
          <td><?php echo htmlspecialchars($row["phone"]); ?></td>
          <td><?php echo htmlspecialchars($row["checkin"]); ?></td>
          <td><?php echo htmlspecialchars($row["checkout"]); ?></td>
          <td><?php echo (int)$row["guests"]; ?></td>
          <td><?php echo htmlspecialchars($row["room_type"]); ?></td>
          <td>
            <?php
              $status = $row["status"];
              $class = "status-badge status-pending";
              if ($status === "confirmed") $class = "status-badge status-confirmed";
              if ($status === "cancelled") $class = "status-badge status-cancelled";
            ?>
            <span class="<?php echo $class; ?>"><?php echo htmlspecialchars($status); ?></span>
          </td>
          <td>
            <div class="action-buttons">
              <a class="btn-action btn-confirm" href="approve.php?id=<?php echo (int)$row["id"]; ?>">Confirm</a>
              <a class="btn-action btn-cancel" onclick="return confirm('Cancel this booking?')" href="cancel.php?id=<?php echo (int)$row["id"]; ?>">Cancel</a>
              <a class="btn-action btn-delete" onclick="return confirm('Delete permanently?')" href="delete.php?id=<?php echo (int)$row["id"]; ?>">Delete</a>
            </div>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php include "footer.php"; ?>
