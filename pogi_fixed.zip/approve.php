<?php
require_once "functions.php";
requireAdminLogin();

$id = (int)($_GET["id"] ?? 0);
if ($id > 0) {
    $stmt = $conn->prepare("UPDATE bookings SET status='confirmed' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
header("Location: admin.php");
exit();
