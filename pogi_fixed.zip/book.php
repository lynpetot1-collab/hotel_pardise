<?php
require_once "config.php";
require_once "functions.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit();
}

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$checkin = trim($_POST["checkin"] ?? "");
$checkout = trim($_POST["checkout"] ?? "");
$guests = (int)($_POST["guests"] ?? 0);
$room_type = trim($_POST["room_type"] ?? "");

if ($name === "" || $email === "" || $phone === "" || $checkin === "" || $checkout === "" || $guests <= 0 || $room_type === "") {
    die("Invalid input.");
}

// simple date check
if (strtotime($checkout) <= strtotime($checkin)) {
    die("Checkout date must be after checkin date.");
}

$reference = generateReference($conn);

$stmt = $conn->prepare("
  INSERT INTO bookings (reference, name, email, phone, checkin, checkout, guests, room_type, status)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
");
$stmt->bind_param("ssssssis", $reference, $name, $email, $phone, $checkin, $checkout, $guests, $room_type);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: index.php?success=1&ref=" . urlencode($reference));
    exit();
}

die("Booking failed: " . htmlspecialchars($stmt->error));
