  </div>
</main>

<footer class="footer">
  <div class="container">
    <p>&copy; <?php echo date("Y"); ?> Hotel Paradise. All Rights Reserved.</p>
  </div>
</footer>
</body>
</html>
