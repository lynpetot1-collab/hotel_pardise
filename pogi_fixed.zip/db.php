<?php
require_once 'config.php';

// Generate booking reference like: HP000001
function generateReferenceNumber(mysqli $conn): string {
    $prefix = "HP";

    $res = $conn->query("SELECT MAX(id) AS max_id FROM bookings");
    $row = $res ? $res->fetch_assoc() : null;
    $nextId = (!empty($row['max_id'])) ? ((int)$row['max_id'] + 1) : 1;

    $ref = $prefix . str_pad((string)$nextId, 6, "0", STR_PAD_LEFT);

    // Ensure uniqueness (extra-safe)
    $stmt = $conn->prepare("SELECT id FROM bookings WHERE reference = ? LIMIT 1");
    $stmt->bind_param("s", $ref);
    $stmt->execute();
    $check = $stmt->get_result();
    $stmt->close();

    if ($check && $check->num_rows > 0) {
        $ref = $ref . substr((string)time(), -3);
    }

    return $ref;
}
?>
